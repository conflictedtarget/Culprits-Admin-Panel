# Hd-Admin

## status: Online 
## api: Online

## script load:
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/conflictedtarget/Hd-Admin/main/HdAdmin.lua",true))()
```
 
## api load:
```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/conflictedtarget/Hd-Admin/main/api%20load.lua",true))()
```
